crosstest <-
function (Z, T) 
{
    T = as.numeric(as.numeric(T) == 1)
    Z = as.matrix(Z)
    n = nrow(Z)
    k = ncol(Z)
    for (j in 1:k) Z[, j] <- rank(Z[, j])
    cv <- cov(Z)
    vuntied <- var(1:n)
    rat <- sqrt(vuntied/diag(cv))
    cv <- diag(rat) %*% cv %*% diag(rat)
    out <- matrix(NA, n, n)
    icov <- ginv(cv)
    for (i in 1:n) out[i, ] <- mahalanobis(Z, Z[i, ], icov, inverted = TRUE)
    return(crossmatchtest(T, out))
}
