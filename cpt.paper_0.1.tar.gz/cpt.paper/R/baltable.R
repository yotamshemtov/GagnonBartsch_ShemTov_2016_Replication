baltable <-
function (Z, T, varnames = NULL, file = "") 
{
    f.stat = function(x1, x0) {
        ks = ks.test(x1, x0)$p.value
        ttest = t.test(x1, x0)$p.value
        wilcox = wilcox.test(x1, x0)$p.value
        return(c(mean(x1, na.rm = TRUE), mean(x0, na.rm = TRUE), 
            ttest, wilcox, ks))
    }
    T = as.numeric(as.factor(T))
    tab = t(mapply(f.stat, as.list(data.frame(Z[T == 1, ])), 
        as.list(data.frame(Z[T == 2, ]))))
    tab = round(tab, dig = 3)
    if (is.null(varnames)) 
        rownames(tab) = colnames(Z)
    else rownames(tab) = varnames
    colnames(tab) = c("Ave. Treat", "Ave. control", "t-test", 
        "Wilcoxon", "KS")
    print(xtable(tab, caption = "Balance table"), file = file)
}
